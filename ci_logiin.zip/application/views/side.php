    <link href="<?= base_url() ?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="<?= base_url()?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="<?= base_url() ?>css/sb-admin.css" rel="stylesheet">
    <div id="wrapper">
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">
            <span>Dasboard</span>
          </a>
        </li>
  
        <li class="nav-item">
          <a class="nav-link" href="<?= base_url(); ?>dosen">
            <span>Dosen</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= base_url(); ?>mahasiswa">
            <span>Mahasiswa</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= base_url(); ?>matakuliah">
            <span>Matakuliah</span></a>
        </li>
       <!-- <li class="nav-item">
          <a class="nav-link" href="<?= base_url(); ?>nilai">
            <span>Nilai</span></a>
        </li>-->
           <!--<li class="nav-item">
          <a class="nav-link" href="<?= base_url(); ?>materi">
            <span>Materi</span></a>
        </li>
        </li>-->
           <li class="nav-item">
          <a class="nav-link" href="<?= base_url('Home/logout') ?>">
            <i class="fas fa-fw fa-table"></i>
            <span>Logout</span></a>
        </li>
      </ul>

         <script src="<?= base_url() ?>vendor/jquery/jquery.min.js"></script>
    <script src="<?= base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="<?= base_url() ?>vendor/chart.js/Chart.min.js"></script>
    <script src="<?= base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?= base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
    <script src="<?= base_url() ?>js/sb-admin.min.js"></script>
    <script src="<?= base_url() ?>js/demo/datatables-demo.js"></script>
    <script src="<?= base_url() ?>js/demo/chart-area-demo.js"></script>